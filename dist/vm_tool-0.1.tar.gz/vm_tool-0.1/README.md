### Welcome to initial setup of the application

1. Connect to deployment machine using VSCode.

2. Run the following command to install the package and its dependencies:
```bash
pip install .